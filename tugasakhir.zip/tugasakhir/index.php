<?php
session_start();

if( isset($_SESSION['akses']) )
{
  header('location:'.$_SESSION['akses']);
  exit();
}

$error = '';
if( isset($_SESSION['error']) ) {

  $error = $_SESSION['error']; 

  unset($_SESSION['error']);
} ?>

<?php echo $error;?>
<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<link rel="shortcut icon" href="icon.ico">
	<!--Import Google Icon Font-->
      <link href="fonts/material.css" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>

      <!--Let browser know website is optimized for mobile-->
       <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <title>Card</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <style type="text/css">
  	.h1{
  		font-size: 32px;
  	}
  	.footer{
  		font-size: 12px;
  	}
  </style>

</head>
<body>
	<div class="row" style="margin-top:10%;">
		<div class="container">
			<!--Form Login-->
			<form method="POST" action="check-login.php">
				<div id="card">
   				 <div id="card-content">
     			 <div id="card-title">
     			 	<img src="logo.jpg" width="100" height="100" class="center">
     			 	<div class="h1" align="center" font="21"> PT PURA NUSA PERSADA UNIT HOLOGRAFI</div>
     			 	<div>
     			 		<p class="login">LOGIN</p>
     			 	</div>
        <div 
        	class="underline-title">
        </div>
      </div>
        <label for="icon_prefix">Nama Pengguna</label>
        <input type="text" name="username" id="icon_prefix" class="validate">
        <label for="icon_prefix">Kata Sandi</label>
		<input type="password" name="password" id="icon_prefix" class="validate">
        <div class="row">
						<div class="col s12 m12 l12 center">
							<input name="login" type="submit" value="Login" class="modal-action modal-close waves-effect waves-light btn blue lighten+10">
						</div>
                  	</div>		
    </div>
    </div>		
  <div class="footer" align="center">
                  	<?php
		$etdy = '2019';
		echo sprintf('Copyright &copy; %s <a href="%s">%s</a>PT Pura Nusa Persada',
		(date("Y")==$etdy) ? $etdy : $etdy.' - '.date("Y"),
		'',
		'' );
		?> All rights reserved.
	


	<!--Import jQuery before materialize.js-->
      <script type="text/javascript" src="js/jquery-3.2.1.min.js"></script>
      <script type="text/javascript" src="js/materialize.min.js"></script>
      <script>
        $( document ).ready(function(){
          Materialize.updateTextFields();
          $('.modal').modal();
        })
      </script>
</body>
</html>