<?php session_start();
include_once("../config.php");
$result = mysqli_query($koneksi, "SELECT * FROM barang_keluar ORDER BY kode_barang DESC");

if( !isset($_SESSION['admin']) )
{
  header('location:./../'.$_SESSION['akses']);
  exit();
}

$nama = ( isset($_SESSION['user']) ) ? $_SESSION['user'] : '';

?>
<!DOCTYPE html>
<html>
<head>
	<title>Gudang Pura</title>
	<link rel="shortcut icon" href="../images/icon.ico">
	<!--Import Google Icon Font-->
    <link href="../fonts/material.css" rel="stylesheet">
    <!--Import materialize.css-->
    <link type="text/css" rel="stylesheet" href="../css/materialize.min.css"  media="screen,projection"/>
    <!--Let browser know website is optimized for mobile-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <style type="text/css">
	       /* label color */
	       .e-input-field label {
	         color: #000;
	       }
	       /* label focus color */
	       .e-input-field input[type=text]:focus + label,.e-input-field input[type=password]:focus + label {
	         color: #d32f2f !important;
	       }
	       /* label underline focus color */
	       .e-input-field input[type=text]:focus,.e-input-field input[type=password]:focus {
	         border-bottom: 1px solid #d32f2f !important;
	         box-shadow: 0 1px 0 0 #d32f2f !important;
	       }
	       /* valid color */
	       .e-input-field input[type=text].valid,.e-input-field input[type=password].valid {
	         border-bottom: 1px solid #d32f2f !important;
	         box-shadow: 0 1px 0 0 #d32f2f !important;
	       }
	       /* invalid color */
	       .e-input-field input[type=text].invalid,.e-input-field input[type=password].invalid {
	         border-bottom: 1px solid #d32f2f !important;
	         box-shadow: 0 1px 0 0 #d32f2f !important;
	       }
	       /* icon prefix focus color */
	       .e-input-field .prefix.active {
	         color: #d32f2f !important;
	       }
	    </style>
</head>
<body>
    <center>
        <h2>LAPORAN DATA BARANG KELUAR</h2>
        <hr />
    </center>
    <table border="1" style="width: 100%">
        <tr>
            <th>Kode Barang</th>
            <th>Nama Barang</th>
            <th>Tujuan Barang</th>
            <th>Tanggal Keluar</th>
            <th>Petugas</th>
        </tr>
        <?php 

                            while($user_data = mysqli_fetch_array($result)) { 
                                $test = $user_data['nama_barang'];      
                                echo "<tr>";
                                echo "<td hidden>".$user_data['id']."</td>";
                                echo "<td>".$user_data['kode_barang']."</td>";
                                echo "<td>".$user_data['nama_barang']."</td>";
                                echo "<td>".$user_data['tujuan']."</td>";
                                echo "<td>".$user_data['tanggal']."</td>"; 
                                echo "<td>".$user_data['operator']."</td>";    
                                echo "<td> ";  
                            }

        ?>
    </table>
    <script>
        window.print();
    </script>
</body>
</html>