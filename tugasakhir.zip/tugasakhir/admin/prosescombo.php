<?php
$id_kode = $_POST[‘id_kode’];
if ($id_kode == ‘0’) {
echo "anda belum memilih";
} else
echo "anda memilih ".$id_kode;
?>